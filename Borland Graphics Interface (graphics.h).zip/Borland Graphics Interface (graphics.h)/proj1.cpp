#include "graphics.h"

int main (void)
{
  int i=0, gd, gm;
  gd = DETECT;
  initgraph (&gd, &gm, "");
  setbkcolor (BLACK);
  cleardevice ();
  outtextxy (0, 0, "Drawing 1000 lines...");
  circle(200, 200, 50);
  int x=0, y=0;
/*
  while(1)
  {
	  x=mousex();
	  y=mousey();
	  cleardevice ();
	  circle(x,y,100);
  }

  while(i<1000)
	{
		cleardevice();
		circle(100+i, 50, 40);
		delay(10);
		i++;
	}

    while (!kbhit( ))
    {
        delay(200);
    }

	 */
  for (i = 0; i < 100; i++)
  {
    setcolor (1 + i ); 
	line (i*10,i,200,200);
	delay(200);
  }
   
  getch ();
  closegraph ();
  return 0;
}


